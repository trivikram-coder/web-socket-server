//Sorry currently facing some issues with Ts.
//Please prefer other languages
let x: number = 10;
console.log(x);